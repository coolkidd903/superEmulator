@echo off
setlocal
cd /d "%~dp0"
where curl >nul 2>nul
if errorlevel 1 (
  echo [ERROR] curl not found. Download the four files manually using DOWNLOAD-LINKS.txt
  pause
  exit /b 1
)
echo Downloading official v86 assets...
curl -fL --retry 2 "https://github.com/copy/v86/releases/latest/download/libv86.js" -o "libv86.js" || goto :fail
curl -fL --retry 2 "https://github.com/copy/v86/releases/latest/download/v86.wasm" -o "v86.wasm" || goto :fail
curl -fL --retry 2 "https://raw.githubusercontent.com/copy/v86/master/bios/seabios.bin" -o "seabios.bin" || goto :fail
curl -fL --retry 2 "https://raw.githubusercontent.com/copy/v86/master/bios/vgabios.bin" -o "vgabios.bin" || goto :fail
echo.
echo [OK] Download complete. Files:
dir /b libv86.js v86.wasm seabios.bin vgabios.bin
echo.
echo Start a local web server in this folder, then open http://localhost:8000/
echo Example: python -m http.server 8000
pause
exit /b 0
:fail
echo.
echo [ERROR] Download failed. Check network access and DOWNLOAD-LINKS.txt.
pause
exit /b 1
