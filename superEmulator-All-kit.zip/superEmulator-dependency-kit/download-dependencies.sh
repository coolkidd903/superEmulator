#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
command -v curl >/dev/null 2>&1 || { echo 'curl not found; use DOWNLOAD-LINKS.txt'; exit 1; }
curl -fL --retry 2 'https://github.com/copy/v86/releases/latest/download/libv86.js' -o libv86.js
curl -fL --retry 2 'https://github.com/copy/v86/releases/latest/download/v86.wasm' -o v86.wasm
curl -fL --retry 2 'https://raw.githubusercontent.com/copy/v86/master/bios/seabios.bin' -o seabios.bin
curl -fL --retry 2 'https://raw.githubusercontent.com/copy/v86/master/bios/vgabios.bin' -o vgabios.bin
printf '\n[OK] Dependencies downloaded.\n'
printf 'Start with: python3 -m http.server 8000\nThen open: http://localhost:8000/\n'
